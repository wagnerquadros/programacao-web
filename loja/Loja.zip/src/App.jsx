import Rodape from "./components/Rodape"
import Nav from "./components/Nav"
import Carrinho from "./components/Carrinho"
import ListaProdutos from "./components/ListaProdutos"
import CardProduto from "./components/CardProduto"


function App() {

  return (
      <CardProduto/>

  )
}

export default App
