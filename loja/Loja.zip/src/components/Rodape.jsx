function Rodape() {
    return (
        <>
            <footer>
                <div className="bg-primary text-center">
                    <span className="navbar-brand mb-0  text-bg-primary">All Rights</span>
                </div>
            </footer>
        </>
    )
}

export default Rodape