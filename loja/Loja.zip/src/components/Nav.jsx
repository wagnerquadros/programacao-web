function Nav(){

    return (
        <nav class="navbar bg-primary">
            <div class="container-fluid text-center">
                <span class="navbar-brand mb-0 h1  text-bg-primary">Milha Loja</span>
            </div>
        </nav>
    )
}

export default Nav